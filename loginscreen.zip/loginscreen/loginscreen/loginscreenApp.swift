//
//  loginscreenApp.swift
//  loginscreen
//
//  Created by Alumno on 03/04/24.
//

import SwiftUI

@main
struct loginscreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
